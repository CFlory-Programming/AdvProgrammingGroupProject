package src;

import processing.core.PApplet;

public class Plane {
    public double x, y, z;
    public double rotX, rotY, rotZ;
    public double width, height;
    public int c1, c2, c3;

    public Plane(double x, double y, double z, double rotX, double rotY, double rotZ, double width, double height, int c1, int c2, int c3) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.rotX = rotX;
        this.rotY = rotY;
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.rotZ = rotZ;
        this.width = width;
        this.height = height;
    }

    private double[] rotatePoint(double px, double py, double pz) {
        // Rotate around Z
        double cosz = Math.cos(rotZ);
        double sinz = Math.sin(rotZ);
        double x1 = px * cosz - py * sinz;
        double y1 = px * sinz + py * cosz;
        double z1 = pz;

        // Rotate around Y
        double cosy = Math.cos(rotY);
        double siny = Math.sin(rotY);
        double x2 = x1 * cosy + z1 * siny;
        double z2 = -x1 * siny + z1 * cosy;
        double y2 = y1;

        // Rotate around X
        double cosx = Math.cos(rotX);
        double sinx = Math.sin(rotX);
        double y3 = y2 * cosx - z2 * sinx;
        double z3 = y2 * sinx + z2 * cosx;
        double x3 = x2;

        return new double[]{x3 + x, y3 + y, z3 + z};
    }

    private float[] project(double px, double py, double pz, double cx, double cy, double cz, double rx, double ry) {
        // Translate to camera space
        px -= cx;
        py -= cy;
        pz -= cz;

        // Rotate by -ry around Y
        double cosry = Math.cos(-ry);
        double sinry = Math.sin(-ry);
        double x1 = px * cosry + pz * sinry;
        double z1 = -px * sinry + pz * cosry;
        double y1 = py;

        // Rotate by -rx around X
        double cosrx = Math.cos(-rx);
        double sinrx = Math.sin(-rx);
        double y2 = y1 * cosrx - z1 * sinrx;
        double z2 = y1 * sinrx + z1 * cosrx;
        double x2 = x1;

        if (z2 <= 0) return null; // Behind camera

        double f = 500; // Focal length
        float sx = (float)(x2 / z2 * f + 400); // Center at width/2
        float sy = (float)(-y2 / z2 * f + 300); // Center at height/2
        return new float[]{sx, sy};
    }

    public void display(PApplet app, double camX, double camY, double camZ, double camRotX, double camRotY) {
        // Get world positions of the three vertices
        double[] p1 = rotatePoint(-width / 2, -height / 2, 0);
        double[] p2 = rotatePoint(width / 2, -height / 2, 0);
        double[] p3 = rotatePoint(0, height / 2, 0);

        // Project to screen coordinates
        float[] s1 = project(p1[0], p1[1], p1[2], camX, camY, camZ, camRotX, camRotY);
        float[] s2 = project(p2[0], p2[1], p2[2], camX, camY, camZ, camRotX, camRotY);
        float[] s3 = project(p3[0], p3[1], p3[2], camX, camY, camZ, camRotX, camRotY);

        if (s1 != null && s2 != null && s3 != null) {
            app.fill(c1, c2, c3); // Red color
            app.beginShape();
            app.vertex(s1[0], s1[1]);
            app.vertex(s2[0], s2[1]);
            app.vertex(s3[0], s3[1]);
            app.endShape(PApplet.CLOSE);
        }
    }

    public double getDistanceToCamera(double camX, double camY, double camZ) {
        double dx = x - camX;
        double dy = y - camY;
        double dz = z - camZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}