package src;

import java.util.*;
import processing.core.PApplet;
public class Main extends PApplet {

    public static PApplet app;
    public static List<Plane> planes = new ArrayList<>();

    public static double cameraX = 0;
    public static double cameraY = 0;
    public static double cameraZ = 0;
    public static double cameraRotX = 0;
    public static double cameraRotY = 0;

    public static boolean keys[] = new boolean[10];
    public static void main(String[] args) {
        PApplet.main("src.Main");
    }

    @Override
    public void settings() {
        fullScreen();
    }

    @Override
    public void setup() {
        background(255);
        noStroke();
        frameRate(30);
        
        app = this;

        planes.add(new Plane(-150, 0, 300, 0, 0.5, 0.5, 100, 100, 0, 255, 255));
        planes.add(new Plane(0, 0, 100, 0, 0, 0, 100, 100, 255, 0, 0));
        planes.add(new Plane(150, 0, 200, 0.5, 0.5, 0, 100, 100, 0, 255, 0));
    }

    @Override
    public void draw() {

        if (keys[0]) cameraZ += 5;
        if (keys[1]) cameraZ -= 5;
        if (keys[2]) cameraX -= 5;
        if (keys[3]) cameraX += 5;
        if (keys[4]) cameraY -= 5;
        if (keys[5]) cameraY += 5;
        if (keys[6]) cameraRotX += 0.1;
        if (keys[7]) cameraRotX -= 0.1;
        if (keys[8]) cameraRotY += 0.1;
        if (keys[9]) cameraRotY -= 0.1;

        sort();

        background(255);
        for (Plane p : planes) {
            p.display(this, cameraX, cameraY, cameraZ, cameraRotX, cameraRotY);
        }
    }

    public void sort() {
        planes.sort((p1, p2) -> {
            double d1 = p1.getDistanceToCamera(cameraX, cameraY, cameraZ);
            double d2 = p2.getDistanceToCamera(cameraX, cameraY, cameraZ);
            return Double.compare(d2, d1);
        });
    }

    @Override
    public void keyPressed() {
        if (key == 'w') keys[0] = true;
        if (key == 's') keys[1] = true;
        if (key == 'a') keys[2] = true;
        if (key == 'd') keys[3] = true;
        if (key == 'q') keys[4] = true;
        if (key == 'e') keys[5] = true;
        if (keyCode == UP) keys[6] = true;
        if (keyCode == DOWN) keys[7] = true;
        if (keyCode == LEFT) keys[8] = true;
        if (keyCode == RIGHT) keys[9] = true;
    }
    
    @Override
    public void keyReleased() {
        if (key == 'w') keys[0] = false;
        if (key == 's') keys[1] = false;
        if (key == 'a') keys[2] = false;
        if (key == 'd') keys[3] = false;
        if (key == 'q') keys[4] = false;
        if (key == 'e') keys[5] = false;
        if (keyCode == UP) keys[6] = false;
        if (keyCode == DOWN) keys[7] = false;
        if (keyCode == LEFT) keys[8] = false;
        if (keyCode == RIGHT) keys[9] = false;
    }
}
